#include <stdio.h>

int main() {
    int duerme, contador;
contador=0;


    printf("ingrese cuantas horas desea dormir = ");
    scanf("%d", &duerme);
   
     
    while(duerme>contador){
       printf("ZzZzZzZz....");
       
        contador++;
         
    }
    {

    
    printf("¡Es hora de levantarse!");

}

    return 0;
}